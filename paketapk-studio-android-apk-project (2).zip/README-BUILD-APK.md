# PaketAPK Studio — Panduan Build APK Android

Konfigurasi Paket:
- App Name: PaketAPK Studio
- Application ID: com.paketapk.studio
- Version: 1.0.0 (versionCode 1)
- SDK: minSdk 24 / targetSdk 35

## Opsi 1: Build APK Otomatis di GitHub Actions (Tanpa Install Android Studio)

1. Ekstrak file ZIP ini ke folder proyek Anda.
2. Buat repository baru di GitHub dan push seluruh isi folder ini ke branch `main`.
3. Buka tab **Actions** di repository GitHub Anda.
4. Workflow `Build PaketAPK Studio APK` akan berjalan otomatis (~2-3 menit).
5. Setelah selesai, unduh file `app-debug.apk` dari bagian **Artifacts** dan pasang langsung di HP Android.

## Opsi 2: Build APK di Komputer Lokal (Android Studio / Gradle)

Prasyarat: Node.js 20+, Java JDK 17, dan Android SDK.

```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

File APK hasil build akan berada di:
`android/app/build/outputs/apk/debug/app-debug.apk`
