import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.paketapk.studio',
  appName: 'PaketAPK Studio',
  webDir: 'dist',
  server: {
    url: 'https://ais-dev-ejiukrkxmo7eghxkvontun-734729332179.europe-west2.run.app',
    cleartext: false,
  },
  android: {
    allowMixedContent: false,
    backgroundColor: '#0f172a',
    buildOptions: {
      releaseType: 'APK',
    },
  },
};

export default config;
